from model_tictactoe import Board

def CreateBoard(b):#define a method which is used to create the board of the game
    b.label1.grid(row=0,column=0,columnspan=3,padx=5, pady=5)#link label1 with root tkinter window
    
    b.label2.grid(row=1,column=0,columnspan=3,padx=5, pady=5)#link label2 with root tkinter window
    
    b.label3.grid(row=2,column=0,columnspan=3,padx=5, pady=5)#link label3 with root tkinter window
    
    b.b1.grid(row=3,column=0)#link button1 with root tkinter window
    
    b.b2.grid(row=3,column=1)#link button2 with root tkinter window
    
    b.b3.grid(row=3,column=2)#link button3 with root tkinter window
    
    b.b4.grid(row=4,column=0)#link button4 with root tkinter window
    
    b.b5.grid(row=4,column=1)#link button5 with root tkinter window
    
    b.b6.grid(row=4,column=2)#link button6 with root tkinter window
    
    b.b7.grid(row=5,column=0)#link button7 with root tkinter window
    
    b.b8.grid(row=5,column=1)#link button8 with root tkinter window
    
    b.b9.grid(row=5,column=2)#link button9 with root tkinter window
    
    b.b10.grid(row=6,column=0,columnspan=3,padx=5, pady=5)#link button10 with root tkinter window
    b.root.mainloop()

