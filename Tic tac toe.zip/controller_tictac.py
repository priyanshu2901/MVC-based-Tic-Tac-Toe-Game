from model_tictactoe import Board
import view_tictactoe as obj
from tkinter import messagebox
b=Board()#create object of class board present in mpdel_tictactoe file
flag=0

def FirstButton(event):#Event function for button 1
   global flag
   if(b.b1.cget('text')=='-'):#check whether button is already clicked or not
       if(flag==0):
           b.update('X',1)#call update function
           if(b.isWin()==0):#call isWin function
               if b.isTie()==1:#call isTie function
                   b.reset()#call reset function 
           else:
               b.reset()#call reset function 
           flag=1
       else:
           b.update('O',1)#call update function
           if(b.isWin()==0):#call isWin function
               if b.isTie()==1:#call isTie function
                   b.reset()#call reset function 
           else:
               b.reset()#call reset function 
           flag=0
       
   else:
       messagebox.showinfo("Tic-Tac-Toe","Button Already clicked!")
b.b1.bind('<Button-1>', FirstButton)#bind function with button

def SecondButton(event):#Event function for button 2
   global flag
   if(b.b2.cget('text')=='-'):#check whether button is already clicked or not
       if(flag==0):
           b.update('X',2)#call update function
           if(b.isWin()==0):#call isWin function
               if b.isTie()==1:#call isTie function
                   b.reset()
           else:
               b.reset()
           flag=1
       else:
           b.update('O',2)#call update function
           if(b.isWin()==0):#call isWin function
               if b.isTie()==1:#call isTie function
                   b.reset()#call reset function 
           else:
               b.reset()#call reset function 
           flag=0
       
   else:
       messagebox.showinfo("Tic-Tac-Toe","Button Already clicked!")
b.b2.bind('<Button-1>', SecondButton)#bind function with button

def ThirdButton(event):#Event function for button 3
   global flag
   if(b.b3.cget('text')=='-'):#check whether button is already clicked or not
       if(flag==0):
           b.update('X',3)#call update function
           if(b.isWin()==0):#call isWin function
               if b.isTie()==1:#call isTie function
                   b.reset()
           else:
               b.reset()
           flag=1
       else:
           b.update('O',3)#call update function
           if(b.isWin()==0):#call isWin function
               if b.isTie()==1:#call isTie function
                   b.reset()#call reset function 
           else:
               b.reset()#call reset function 
           flag=0
       
   else:
       messagebox.showinfo("Tic-Tac-Toe","Button Already clicked!")
b.b3.bind('<Button-1>', ThirdButton)#bind function with button

def FourthButton(event):#Event function for button 4
   global flag
   if(b.b4.cget('text')=='-'):#check whether button is already clicked or not
       if(flag==0):
           b.update('X',4)#call update function
           if(b.isWin()==0):#call isWin function
               if b.isTie()==1:#call isTie function
                   b.reset()#call reset function 
           else:
               b.reset()#call reset function 
           flag=1
       else:
           b.update('O',4)#call update function
           if(b.isWin()==0):#call isWin function
               if b.isTie()==1:#call isTie function
                   b.reset()#call reset function 
           else:
               b.reset()#call reset function 
           flag=0
       
   else:
       messagebox.showinfo("Tic-Tac-Toe","Button Already clicked!")
b.b4.bind('<Button-1>', FourthButton)#bind function with button


def FifthButton(event):#Event function for button 5
   global flag
   if(b.b5.cget('text')=='-'):#check whether button is already clicked or not
       if(flag==0):
           b.update('X',5)#call update function
           if(b.isWin()==0):#call isWin function
               if b.isTie()==1:#call isTie function
                   b.reset()#call reset function 
           else:
               b.reset()#call reset function 
           flag=1
       else:
           b.update('O',5)#call update function
           if(b.isWin()==0):#call isWin function
               if b.isTie()==1:#call isTie function
                   b.reset()#call reset function 
           else:
               b.reset()#call reset function 
           flag=0
       
   else:
       messagebox.showinfo("Tic-Tac-Toe","Button Already clicked!")
b.b5.bind('<Button-1>', FifthButton)#bind function with button

def SixthButton(event):#Event function for button 6
   global flag
   if(b.b6.cget('text')=='-'):#check whether button is already clicked or not
       if(flag==0):
           b.update('X',6)#call update function
           if(b.isWin()==0):#call isWin function
               if b.isTie()==1:#call isTie function
                   b.reset()#call reset function 
           else:
               b.reset()#call reset function 
           flag=1
       else:
           b.update('O',6)#call update function
           if(b.isWin()==0):#call isWin function
               if b.isTie()==1:#call isTie function
                   b.reset()#call reset function 
           else:
               b.reset()#call reset function 
           flag=0
       
   else:
       messagebox.showinfo("Tic-Tac-Toe","Button Already clicked!")
b.b6.bind('<Button-1>', SixthButton)#bind function with button

def SeventhButton(event):#Event function for button 7
   global flag
   if(b.b7.cget('text')=='-'):#check whether button is already clicked or not
       if(flag==0):
           b.update('X',7)#call update function
           if(b.isWin()==0):#call isWin function
               if b.isTie()==1:#call isTie function
                   b.reset()#call reset function 
           else:
               b.reset()#call reset function 
           flag=1
       else:
           b.update('O',7)#call update function
           if(b.isWin()==0):#call isWin function
               if b.isTie()==1:#call isTie function
                   b.reset()#call reset function 
           else:
               b.reset()#call reset function 
           flag=0
       
   else:
       messagebox.showinfo("Tic-Tac-Toe","Button Already clicked!")
b.b7.bind('<Button-1>', SeventhButton)#bind function with button

def EighthButton(event):#Event function for button 8
   global flag
   if(b.b8.cget('text')=='-'):#check whether button is already clicked or not
       if(flag==0):
           b.update('X',8)#call update function
           if(b.isWin()==0):#call isWin function
               if b.isTie()==1:#call isTie function
                   b.reset()#call reset function 
           else:
               b.reset()#call reset function 
           flag=1
       else:
           b.update('O',8)#call update function
           if(b.isWin()==0):#call isWin function
               if b.isTie()==1:#call isTie function
                   b.reset()#call reset function 
           else:
               b.reset()
           flag=0
       
   else:
       messagebox.showinfo("Tic-Tac-Toe","Button Already clicked!")
b.b8.bind('<Button-1>', EighthButton)#bind function with button


def NinthButton(event):#Event function for button 9
   global flag
   if(b.b9.cget('text')=='-'):#check whether button is already clicked or not
       if(flag==0):
           b.update('X',9)#call update function
           if(b.isWin()==0):#call isWin function
               if b.isTie()==1:#call isTie function
                   b.reset()#call reset function 
           else:
               b.reset()
           flag=1
       else:
           b.update('O',9)#call update function
           if(b.isWin()==0):#call isWin function
               if b.isTie()==1:#call isTie function
                   b.reset()#call reset function 
           else:
               b.reset()#call reset function 
           flag=0
       
   else:
       messagebox.showinfo("Tic-Tac-Toe","Button Already clicked!")
b.b9.bind('<Button-1>', NinthButton)#bind function with button

def ResetButton(event):#Event function for button reset button
   global flag
   flag=0
   b.reset()
b.b10.bind('<Button-1>', ResetButton)#bind function with button



obj.CreateBoard(b)#call CreateBoard function

