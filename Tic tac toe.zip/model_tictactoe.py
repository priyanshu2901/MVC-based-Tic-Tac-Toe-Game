from tkinter import *
from tkinter import messagebox


class Board:
    def __init__(self):
        self.root=Tk()  #creating tkinter window
        self.root.title("Tic-Tac-Toe")   #set title of tkinter window
        self.gamePlayed=0#variable to count number of games played
        self.XWin=0#variable to count number of time x win
        self.YWin=0#variable to count number of time y win
        self.label1=Label(self.root,text="Number of games played : "+str(self.gamePlayed),font= "Verdana 10")#creating label1
        
        self.label2=Label(self.root,text="Number of wins for player X : "+str(self.XWin),font= "Verdana 10")#creating label2
        
        self.label3=Label(self.root,text="Number of wins for player O : "+str(self.YWin),font= "Verdana 10")#creating label3
        
        self.b1 = Button(self.root,text='-',compound=CENTER ,font= "Verdana 15 bold", height=2, width=5,relief="sunken",bd=3)#creating button1
        
        self.b2 = Button(self.root,text='-',compound=CENTER ,font= "Verdana 15 bold", height=2, width=5,relief="sunken",bd=3)#creating button2
        
        self.b3 = Button(self.root,text='-',compound=CENTER ,font= "Verdana 15 bold", height=2, width=5,relief="sunken",bd=3)#creating button3
        
        self.b4 = Button(self.root,text='-',compound=CENTER ,font= "Verdana 15 bold", height=2, width=5,relief="sunken",bd=3)#creating button4
        
        self.b5 = Button(self.root,text='-',compound=CENTER ,font= "Verdana 15 bold", height=2, width=5,relief="sunken",bd=3)#creating button5
        
        self.b6 = Button(self.root,text='-',compound=CENTER ,font= "Verdana 15 bold", height=2, width=5,relief="sunken",bd=3)#creating button6

        self.b7 = Button(self.root,text='-',compound=CENTER ,font= "Verdana 15 bold", height=2, width=5,relief="sunken",bd=3)#creating button7
        
        self.b8 = Button(self.root,text='-',compound=CENTER ,font= "Verdana 15 bold", height=2, width=5,relief="sunken",bd=3)#creating button8
        
        self.b9 = Button(self.root,text='-',compound=CENTER ,font= "Verdana 15 bold", height=2, width=5,relief="sunken",bd=3)#creating button9
        
        self.b10 = Button(self.root,text='New Game',compound=CENTER ,font= "Verdana 10 bold", height=1, width=10,relief="solid",bd=3)#creating button10
    
    def isWin(self):#function to check whether someone won or not
        if (self.b1.cget('text') ==self.b2.cget('text') == self.b3.cget('text')=='X'):
            messagebox.showinfo("Tic-Tac_Toe","'"+self.b1.cget('text')+"' has won")#meesage show when player 1 won
            self.XWin+=1#increase number of times x win with 1
            self.label2["text"] = str("Number of wins for player X : "+str(self.XWin))#change number of time x win in tkinter window
            return 1
        elif (self.b1.cget('text') ==self.b2.cget('text') == self.b3.cget('text')=='O'):
            messagebox.showinfo("Tic-Tac_Toe","'"+self.b1.cget('text')+"' has won")#meesage show when player 2 won
            self.YWin+=1
            self.label3["text"] = str("Number of wins for player O : "+str(self.YWin))#change number of time O win in tkinter window
            return 1#increase number of times O win with 1
        elif (self.b4.cget('text') ==self.b5.cget('text') == self.b6.cget('text')=='X'):
            messagebox.showinfo("Tic-Tac_Toe","'"+self.b5.cget('text')+"' has won")#meesage show when player 1 won
            self.XWin+=1#increase number of times x win with 1
            self.label2["text"] = str("Number of wins for player X : "+str(self.XWin))#change number of time x win in tkinter window
            return 1
        elif (self.b4.cget('text') ==self.b5.cget('text') == self.b6.cget('text')=='O'):
            messagebox.showinfo("Tic-Tac_Toe","'"+self.b5.cget('text')+"' has won")#meesage show when player 2 won
            self.YWin+=1#increase number of times O win with 1
            self.label3["text"] = str("Number of wins for player O : "+str(self.YWin))#change number of time O win in tkinter window
            return 1
        elif (self.b7.cget('text') ==self.b8.cget('text') == self.b9.cget('text')=='X'):
            messagebox.showinfo("Tic-Tac_Toe","'"+self.b8.cget('text')+"' has won")#meesage show when player 1 won
            self.XWin+=1#increase number of times x win with 1
            self.label2["text"] = str("Number of wins for player X : "+str(self.XWin))#change number of time x win in tkinter window
            return 1
        elif (self.b7.cget('text') ==self.b8.cget('text') == self.b9.cget('text')=='O'):
            messagebox.showinfo("Tic-Tac_Toe","'"+self.b8.cget('text')+"' has won")#meesage show when player 2 won
            self.YWin+=1#increase number of times O win with 1
            self.label3["text"] = str("Number of wins for player O : "+str(self.YWin))#change number of time O win in tkinter window
            return 1
        elif (self.b1.cget('text') ==self.b4.cget('text') == self.b7.cget('text')=='X'):
            messagebox.showinfo("Tic-Tac_Toe","'"+self.b4.cget('text')+"' has won")#meesage show when player 1 won
            self.XWin+=1#increase number of times x win with 1
            self.label2["text"] = str("Number of wins for player X : "+str(self.XWin))#change number of time x win in tkinter window
            return 1
        elif (self.b1.cget('text') ==self.b4.cget('text') == self.b7.cget('text')=='O'):
            messagebox.showinfo("Tic-Tac_Toe","'"+self.b4.cget('text')+"' has won")#meesage show when player 2 won
            self.YWin+=1#increase number of times O win with 1
            self.label3["text"] = str("Number of wins for player O : "+str(self.YWin))#change number of time O win in tkinter window
            return 1
        
        elif (self.b2.cget('text') ==self.b5.cget('text') == self.b8.cget('text')=='X'):
            messagebox.showinfo("Tic-Tac_Toe","'"+self.b8.cget('text')+"' has won")#meesage show when player 1 won
            self.XWin+=1#increase number of times x win with 1
            self.label2["text"] = str("Number of wins for player X : "+str(self.XWin))#change number of time x win in tkinter window
            return 1
        elif (self.b2.cget('text') ==self.b5.cget('text') == self.b8.cget('text')=='O'):
            messagebox.showinfo("Tic-Tac_Toe","'"+self.b8.cget('text')+"' has won")#meesage show when player 2 won
            self.YWin+=1#increase number of times O win with 1
            self.label3["text"] = str("Number of wins for player O : "+str(self.YWin))#change number of time O win in tkinter window
            return 1
            
        elif (self.b3.cget('text') ==self.b6.cget('text') == self.b9.cget('text')=='X'):
            messagebox.showinfo("Tic-Tac_Toe","'"+self.b6.cget('text')+"' has won")#meesage show when player 1 won
            self.XWin+=1#increase number of times x win with 1
            self.label2["text"] = str("Number of wins for player X : "+str(self.XWin))#change number of time x win in tkinter window
            return 1
        elif (self.b3.cget('text') ==self.b6.cget('text') == self.b9.cget('text')=='O'):
            messagebox.showinfo("Tic-Tac_Toe","'"+self.b6.cget('text')+"' has won")#meesage show when player 2 won
            self.YWin+=1 #increase number of times O win with 1
            self.label3["text"] = str("Number of wins for player O : "+str(self.YWin))#change number of time O win in tkinter window
            return 1
            
        elif (self.b1.cget('text') ==self.b5.cget('text') == self.b9.cget('text')=='X'):
            messagebox.showinfo("Tic-Tac_Toe","'"+self.b5.cget('text')+"' has won")#meesage show when player 1 won
            self.XWin+=1#increase number of times x win with 1
            self.label2["text"] = str("Number of wins for player X : "+str(self.XWin))#change number of time x win in tkinter window
            return 1
        elif (self.b1.cget('text') ==self.b5.cget('text') == self.b9.cget('text')=='O'):
            messagebox.showinfo("Tic-Tac_Toe","'"+self.b5.cget('text')+"' has won")#meesage show when player 2 won
            self.YWin+=1#increase number of times O win with 1
            self.label3["text"] = str("Number of wins for player O : "+str(self.YWin))#change number of time O win in tkinter window
            return 1
        
        elif (self.b3.cget('text') ==self.b5.cget('text') == self.b7.cget('text')=='X'):
            messagebox.showinfo("Tic-Tac_Toe","'"+self.b5.cget('text')+"' has won")#meesage show when player 1 won
            self.XWin+=1#increase number of times x win with 1
            self.label2["text"] = str("Number of wins for player X : "+str(self.XWin))#change number of time x win in tkinter window
            return 1
        elif (self.b3.cget('text') ==self.b5.cget('text') == self.b7.cget('text')=='O'):
            messagebox.showinfo("Tic-Tac_Toe","'"+self.b5.cget('text')+"' has won")#meesage show when player 2 won
            self.YWin+=1#increase number of times O win with 1
            self.label3["text"] = str("Number of wins for player O : "+str(self.YWin))#change number of time O win in tkinter window
            return 1
        return 0
       
    def isTie(self):#function to check whether game is tied or not
        found=1
        if(self.b1.cget('text')=='-'):
            found=0
        if(self.b2.cget('text')=='-'):
            found=0
        if(self.b3.cget('text')=='-'):
            found=0
        if(self.b4.cget('text')=='-'):
            found=0
        if(self.b5.cget('text')=='-'):
            found=0
        if(self.b6.cget('text')=='-'):
            found=0
        if(self.b7.cget('text')=='-'):
            found=0
        if(self.b8.cget('text')=='-'):
            found=0
        if(self.b9.cget('text')=='-'):
            found=0
        if(found==1):
             messagebox.showinfo("Tic-Tac-Toe","Game Tied!!!")#message show when game tie
             return 1
        return 0
    def update(self,value,ButtonNumber):#function to update the board according to player move
        if(ButtonNumber==1):
             self.b1["text"] = str(value)#change text on board
        elif(ButtonNumber==2):
             self.b2["text"] = str(value)#change text on board
        elif(ButtonNumber==3):
             self.b3["text"] = str(value)#change text on board
        elif(ButtonNumber==4):
             self.b4["text"] = str(value)#change text on board
        elif(ButtonNumber==5):
             self.b5["text"] = str(value)#change text on board
        elif(ButtonNumber==6):
             self.b6["text"] = str(value)#change text on board
        elif(ButtonNumber==7):
             self.b7["text"] = str(value)#change text on board
        elif(ButtonNumber==8):
             self.b8["text"] = str(value)#change text on board
        elif(ButtonNumber==9):
             self.b9["text"] = str(value)#change text on board
    def reset(self):#function to reset the game
         self.gamePlayed+=1#increment number of games with 1
         self.label1["text"] = str("Number of games played  : "+str(self.gamePlayed))#change the number of game in tkinter window
         self.b1["text"] = str('-')#set button to its initial value
         self.b2["text"] = str('-')#set button to its initial value
         self.b3["text"] = str('-')#set button to its initial value
         self.b4["text"] = str('-')#set button to its initial value
         self.b5["text"] = str('-')#set button to its initial value
         self.b6["text"] = str('-')#set button to its initial value
         self.b7["text"] = str('-')#set button to its initial value
         self.b8["text"] = str('-')#set button to its initial value
         self.b9["text"] = str('-')#set button to its initial value
        
            
            
            
            
             
            
                
       
        
        
        

    
